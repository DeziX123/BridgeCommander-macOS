Fictional sample archive for Bridge Commander.
